#!/usr/bin/env python
# -*- coding: UTF-8 -*-

print("Bonjour à tout le monde!")
